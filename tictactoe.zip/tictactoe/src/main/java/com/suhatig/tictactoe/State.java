package com.suhatig.tictactoe;

public enum State {
    NON, X, O;
}
