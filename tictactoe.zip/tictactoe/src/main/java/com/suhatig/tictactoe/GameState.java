package com.suhatig.tictactoe;

public enum GameState {
    BEFORE, READY, RUNNING, AFTER, NON
}
